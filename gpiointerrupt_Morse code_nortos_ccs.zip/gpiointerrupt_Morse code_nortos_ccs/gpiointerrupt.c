/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Driver Timer header files */

#include <ti/drivers/Timer.h>

#define TIMER_PERIOD_US 500000 //500 ms period


/* Morse code def */

#define DOT_DURATION 200000      // 200 ms duration per dot
#define DASH_DURATION 600000     // 600 ms duration per dash
#define PAUSE_DURATION 400000    // 400 ms pause between elements of the same letter
#define LETTER_PAUSE 800000      // 800 ms pause between letters
#define WORD_PAUSE 1600000       // 1600 ms pause between words


/* State machine state */
#define STATE_SOS 0
#define STATE_OK  1

static const char *message_sos = "... --- ...";
static const char *message_ok = "--- -.-";

/* LED states */

static uint8_t current_state = STATE_SOS;  // Start with SOS message
static uint8_t current_letter = 0;         // Index of current letter being blinked
static uint32_t current_duration = 0;       // Current duration counter
static uint32_t next_timer_interval = TIMER_PERIOD_US;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    /* Call the state machine */
    switch (current_state) {
        case STATE_SOS:
            // Blink SOS message
            blinkMorseMessage(message_sos);
            break;
        case STATE_OK:
            // Blink OK message
            blinkMorseMessage(message_ok);
            break;
        default:
            break;
    }
}


void blinkMorseMessage(const char *message)
{
    char current_char = message[current_letter];
    switch (current_char) {
        case '.':
            // Dot: toggle LED for DOT_DURATION
            toggleLEDs(1); // Toggle LEDs on
            current_duration += DOT_DURATION;
            break;
        case '-':
            // Dash: toggle LED for DASH_DURATION
            toggleLEDs(1); // Toggle LEDs on
            current_duration += DASH_DURATION;
            break;
        case ' ':
            // Pause between elements of the same letter
            toggleLEDs(0); // Toggle LEDs off
            current_duration += PAUSE_DURATION;
            break;
        case '/':
            // Pause between letters
            toggleLEDs(0); // Toggle LEDs off
            current_duration += LETTER_PAUSE;
            break;
        default:
            // End of message or unrecognized character
            toggleLEDs(0); // Toggle LEDs off
            current_duration += WORD_PAUSE;
            break;
    }

    if (current_duration >= next_timer_interval) {
            current_letter++;
            current_duration = 0;

            if (message[current_letter] == '\0') {
                // End of message, reset to the beginning
                current_letter = 0;
                current_duration = 0;
                current_state = (current_state == STATE_SOS) ? STATE_OK : STATE_SOS;
                next_timer_interval = WORD_PAUSE; // Pause between different messages
            }
        }
    }

void toggleLEDs(uint8_t state)
{
    if (state) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Green LED
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);  // Red LED
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, !CONFIG_GPIO_LED_ON); // Green LED
        GPIO_write(CONFIG_GPIO_LED_1, !CONFIG_GPIO_LED_ON); // Red LED
    }
}



/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn(uint_least8_t index)
{
    // Toggle between SOS and OK messages
    current_state = (current_state == STATE_SOS) ? STATE_OK : STATE_SOS;
    current_letter = 0;
    current_duration = 0;
    next_timer_interval = TIMER_PERIOD_US; // Reset to normal timer interval
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();

    Timer_Params_init(&params);
    params.period = TIMER_PERIOD_US;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /* Initialize Timer */
    initTimer();

    return (NULL);
}
